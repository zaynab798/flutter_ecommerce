List<String> Listimages = [
  "img/carousel1.png",
  "img/carousel2.jpeg",
  "img/carousel3.jpg",
  "img/carousel4.png",
];

List<String> Listcategories = [
  "img/CatFurniture.jpg",
  "img/catbeauty.jpg",
  "img/CatLaptops.png",
  "img/CatPhones.png",
  "img/CatShoes.jpg",
  "img/CatWatches.jpg",
];

List<String> Listmarks = [
  "img/addidas.jpg",
  "img/apple.jpg",
  "img/Dell.jpg",
  "img/h&m.jpg",
  "img/Huawei.jpg",
  "img/nike.jpg",
  "img/samsung.jpg",
];

import 'package:flutter/material.dart';
import 'package:flutter_ecommerce/projet_e_commerce/const/images.dart';
import 'package:flutter_ecommerce/projet_e_commerce/myWidgets/carousel_image.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _MyWidgetState();
}

class _MyWidgetState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Page d'accueil"),
        centerTitle: true,
        backgroundColor: Colors.blue,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          ImageCarousel(),
             Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Categories",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.deepOrangeAccent,
                  ),
                  textAlign: TextAlign.left,
                ),
                SizedBox(height: 10),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Image.asset(
                      Listcategories[0],
                      height: 100,
                      width: 100,
                      fit: BoxFit.cover,
                    ),
                    Image.asset(
                      Listcategories[1],
                      height: 100,
                      width: 100,
                      fit: BoxFit.cover,
                    ),
                    Image.asset(
                      Listcategories[2],
                      height: 100,
                      width: 100,
                      fit: BoxFit.cover,
                    ),
                    Image.asset(
                      Listcategories[3],
                      height: 100,
                      width: 100,
                      fit: BoxFit.cover,
                    ),
                    Image.asset(
                      Listcategories[4],
                      height: 100,
                      width: 100,
                      fit: BoxFit.cover,
                    ),
                    Image.asset(
                      Listcategories[5],
                      height: 100,
                      width: 100,
                      fit: BoxFit.cover,
                    ),
                  ],
                ),
              ],
            ),
          Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Marques Populaire",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.deepOrangeAccent,
                  ),
                  textAlign: TextAlign.left,
                ),
                SizedBox(height: 10),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Image.asset(
                      Listmarks[0],
                      height: 100,
                      width: 100,
                      fit: BoxFit.cover,
                    ),
                    Image.asset(
                      Listmarks[1],
                      height: 100,
                      width: 100,
                      fit: BoxFit.cover,
                    ),
                    Image.asset(
                      Listmarks[2],
                      height: 100,
                      width: 100,
                      fit: BoxFit.cover,
                    ),
                    Image.asset(
                      Listmarks[3],
                      height: 100,
                      width: 100,
                      fit: BoxFit.cover,
                    ),
                    Image.asset(
                      Listmarks[4],
                      height: 100,
                      width: 100,
                      fit: BoxFit.cover,
                    ),
                    Image.asset(
                      Listmarks[5],
                      height: 100,
                      width: 100,
                      fit: BoxFit.cover,
                    ),
                  ],
                ),
              ],
            ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        showSelectedLabels: true,
        showUnselectedLabels: true,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Colors.amber,
        unselectedItemColor: Colors.blueGrey,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'Settings',
          ),
        ],
      ),
    );
  }
}
